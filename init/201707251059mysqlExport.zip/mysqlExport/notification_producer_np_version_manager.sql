-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: rm-wz9x07x9567465305o.mysql.rds.aliyuncs.com    Database: notification_producer
-- ------------------------------------------------------
-- Server version	5.6.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
SET @MYSQLDUMP_TEMP_LOG_BIN = @@SESSION.SQL_LOG_BIN;
SET @@SESSION.SQL_LOG_BIN= 0;

--
-- GTID state at the beginning of the backup 
--

SET @@GLOBAL.GTID_PURGED='b6d46ecd-aa52-11e6-a981-6c92bf3a38f0:1-76928541,
c45c2091-aa52-11e6-a981-6c92bf3a38f4:1-4';

--
-- Table structure for table `np_version_manager`
--

DROP TABLE IF EXISTS `np_version_manager`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_version_manager` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `table_name` varchar(40) DEFAULT NULL,
  `notification_table_name` varchar(40) DEFAULT NULL,
  `desc` varchar(30) DEFAULT NULL,
  `last_time` datetime DEFAULT NULL,
  `table_type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uidx_table_name` (`table_name`)
) ENGINE=InnoDB AUTO_INCREMENT=268 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_version_manager`
--

LOCK TABLES `np_version_manager` WRITE;
/*!40000 ALTER TABLE `np_version_manager` DISABLE KEYS */;
INSERT INTO `np_version_manager` VALUES (143,'iap.follow_item','iap.notification','阿里云','2017-07-24 16:51:27','MYSQL'),(144,'enterprise_data_gov_change_info',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(145,'enterprise_owing_tax',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(146,'penalty',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(147,'judge_process',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(148,'shixin_info',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(149,'bulletin',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(150,'court_ktgg',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(151,'tax_payer_level_A',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(152,'judgement_wenshu',NULL,NULL,'2017-07-25 02:15:00','MONGODB'),(153,'bid_detail',NULL,NULL,'2017-07-25 02:15:00','MONGODB');
/*!40000 ALTER TABLE `np_version_manager` ENABLE KEYS */;
UNLOCK TABLES;
SET @@SESSION.SQL_LOG_BIN = @MYSQLDUMP_TEMP_LOG_BIN;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-25 10:48:24
