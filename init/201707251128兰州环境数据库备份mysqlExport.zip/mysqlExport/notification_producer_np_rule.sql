-- MySQL dump 10.13  Distrib 5.7.17, for macos10.12 (x86_64)
--
-- Host: 172.16.215.10    Database: notification_producer
-- ------------------------------------------------------
-- Server version	5.5.5-10.1.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `np_rule`
--

DROP TABLE IF EXISTS `np_rule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `np_rule` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `mongodb_table_name` varchar(40) DEFAULT NULL,
  `desc` varchar(30) DEFAULT NULL COMMENT '规则相关的信息',
  `operation_field` varchar(60) DEFAULT NULL,
  `trigger_condition` varchar(60) NOT NULL COMMENT '规则触发条件',
  `push_title` varchar(30) DEFAULT NULL COMMENT '推送标题',
  `push_title_field` varchar(20) DEFAULT NULL COMMENT '推送标题根据字段',
  `push_content_type` varchar(20) DEFAULT NULL,
  `push_content_field` varchar(20) DEFAULT NULL COMMENT '推送内容',
  `rule_type` int(11) DEFAULT NULL COMMENT '规则类型 例如：风险规则',
  `rule_push_type` int(11) DEFAULT NULL COMMENT '规则推送类型 隶属于 规则类型的 子类型  例如 ：开庭公告',
  `field_enddate` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `np_rule`
--

LOCK TABLES `np_rule` WRITE;
/*!40000 ALTER TABLE `np_rule` DISABLE KEYS */;
INSERT INTO `np_rule` VALUES (1,'court_ktgg','企业涉诉','litigant_list','0',NULL,'case_cause','ALL',NULL,0,0,'court_time'),(2,'bulletin','企业涉诉','litigant_list','0',NULL,'case_cause','ALL',NULL,0,0,'bulletin_date'),(3,'judge_process','企业涉诉','litigant_list','0',NULL,'case_id,status','ALL',NULL,0,0,'filing_date'),(4,'judgement_wenshu','企业涉诉','litigant_list','0',NULL,'case_cause','ALL',NULL,0,0,'case_date'),(5,'shixin_info','企业失信被执行','i_name','0','失信被执行',NULL,'ALL',NULL,0,1,'publish_date'),(6,'enterprise_owing_tax','企业欠税被披露','company','0','欠税披露',NULL,'ALL',NULL,0,2,NULL),(7,'penalty','企业被行政处罚','accused_name','0',NULL,'title','ALL',NULL,0,3,'publish_time'),(8,'enterprise_data_gov_change_info','企业特殊情况-需要特殊处理','field','-1',NULL,NULL,'CUSTOM',NULL,-1,4,NULL),(9,'tax_payer_level_A','企业被公布纳税等级为A','taxpayer_name','0','企业被公布纳税等级为A',NULL,'ALL',NULL,1,6,'year'),(10,'bid_detail','企业中标','win_bid_company,public_bid_company','0',NULL,'title','ALL',NULL,1,7,'bid_date');
/*!40000 ALTER TABLE `np_rule` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-07-25 11:27:38
